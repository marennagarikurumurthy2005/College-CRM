from django.shortcuts import render, redirect
from .models import Student

# View to list all students
def student_list(request):
    students = Student.objects.all()
    return render(request, 'student.html', {"allstudents": students})

# View to add a new student
def add_student(request):
    if request.method == "POST":
        name = request.POST.get('name')
        rollno = request.POST.get('rollno')
        contact = request.POST.get('contact')
        mail = request.POST.get('mail')
        image = request.FILES.get('image')

        student = Student(
            name=name,
            rollno=rollno,
            contact=contact,
            mail=mail,
            image=image if image else None
        )
        student.save()
        return redirect('all-students')

    return render(request, 'student.html')

# View to update student
def update_student(request, id):
    if request.method == 'POST':
        name = request.POST.get('name')
        rollno = request.POST.get('rollno')
        contact = request.POST.get('contact')
        mail = request.POST.get('mail')
        image = request.FILES.get('image')

        student = Student(
            id=id,
            name=name,
            rollno=rollno,
            contact=contact,
            mail=mail,
            image=image if image else None
        )
        student.save()
        return redirect('all-students')

    return render(request, 'student.html', {'student': student})

# View to delete student
def delete_student(request, id):
    student = Student.objects.filter(id=id)
    student.delete()
    return redirect('all-students')
