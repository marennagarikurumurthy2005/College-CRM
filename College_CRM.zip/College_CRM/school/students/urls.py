from django.urls import path
from . import views

urlpatterns = [
    path('/students/', views.student_list, name='all-students'),
    path('addstudent/', views.add_student, name='add_student'),
    path('update-student/<str:id>/', views.update_student, name='update_student'),
    path('delete-student/<str:id>/', views.delete_student, name='delete_student'),
]
