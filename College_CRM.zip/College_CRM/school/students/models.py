from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    rollno = models.CharField(max_length=20, unique=True)
    contact = models.CharField(max_length=15)
    mail = models.EmailField(unique=True)
    image = models.ImageField(upload_to='student_images/', blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.rollno})"
