from django.shortcuts import  render, redirect
from .models import Teacher

# View to list all teachers
def teacher_list(request):
    teachers = Teacher.objects.all()
    return render(request, 'index.html', {"allteachers": teachers})

# View to add a new teacher
def add_teacher(request):
    
    if request.method == "POST":
        name = request.POST.get('name')
        subject = request.POST.get('subject')
        contact = request.POST.get('contact')
        mail = request.POST.get('mail')
        image = request.FILES.get('image')  # Use request.FILES for uploaded files

        teacher = Teacher(
            name=name,
            subject=subject,
            contact=contact,
            mail=mail,  
            image=image if image else None
        )
        teacher.save()
        return redirect('all-teachers')

    return render(request, 'index.html')


def teacher_update(request,id):
    
    if request.method=='POST':
       name = request.POST.get('name')
       subject = request.POST.get('subject')
       contact = request.POST.get('contact')
       mail = request.POST.get('mail')
       image = request.FILES.get('image')

       teacher=Teacher(
           id=id,
           name=name,
            subject=subject,
            contact=contact,
            mail=mail,  
            image=image if image else None
       )  
       teacher.save() 
       return redirect('all-teachers')
    return render(request,'index.html',{'teacher':teacher})
    

def delete_teacher(request,id):
    teacher=Teacher.objects.filter(id=id)
    teacher.delete()
    
    return redirect('all-teachers');